I have changed the extension of the a3.cpp to a3.cu.
Profling available on this datasheet: https://goo.gl/zQLXWN